package com.lcpan.db;

public class ConnConst {
	public static final String JDBC_DRIVER = 
			"com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = 
			"jdbc:mysql://localhost:3306/jdbc";
	public static final String USER = "root";
	public static final String PASSWORD = "P@ssw0rd";
}
